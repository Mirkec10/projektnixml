<?php
$championsData = json_decode(file_get_contents('champs.json'), true);

if (!$championsData) {
    echo "Greška pri učitavanju JSON fajla!";
    exit;
}

function formatCountryName($country) {
    $map = [
        'Š' => 's',
        'č' => 'c',
        'ć' => 'c',
        'ž' => 'z',
        'đ' => 'd',
        ' ' => ''
    ];
    return strtolower(strtr($country, $map));
}
?>

<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tablica Pobijednika</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header class="d-flex justify-content-between align-items-center">
        <img src="images/logo.png" alt="Logo">
        <nav>
            <a href="index.php">Home</a>
            <a href="averages.php">Player Averages</a>
            <a href="champions.php">Champions</a>
        </nav>
    </header>
    
    <div class="container">
        <h2>Board of Champs</h2>
        <div class="table-responsive">
            <table class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>Godina</th>
                        <th>Pobjednik</th>
                        <th>Rezultat</th>
                        <th>Finalist</th>
                        <th>Zastava</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($championsData as $champ): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($champ['year']); ?></td>
                            <td><?php echo htmlspecialchars($champ['winner']); ?></td>
                            <td><?php echo htmlspecialchars($champ['score']); ?></td>
                            <td><?php echo htmlspecialchars($champ['runner_up']); ?></td>
                            <td><img src="zastave/<?php echo htmlspecialchars(formatCountryName($champ['country'])); ?>.png" alt="<?php echo htmlspecialchars($champ['country']); ?>" width="20" height="15"></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
