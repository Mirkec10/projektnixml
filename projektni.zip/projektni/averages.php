<?php
$data = file_get_contents('averages.json');
$players = json_decode($data, true);
?>

<!DOCTYPE html>
<html lang="hr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>World Darts Championship - Prosječni bodovi igrača</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="averages.css">
</head>
<body>
  <header class="d-flex justify-content-between align-items-center">
    <img src="images/logo.png" alt="Logo">
    <nav>
      <a href="index.php">Home</a>
      <a href="averages.php">Averages</a>
      <a href="champions.php">Champions</a>
    </nav>
  </header>

  <div class="container table-container">
    <h1>Top 10 Averages</h1>

    <table class="table table-striped table-bordered">
      <thead>
        <tr>
          <th>Name</th>
          <th>12 Month Average</th>
          <th>Average when 1 Leg Away from Winning</th>
          <th>Average when 1 Leg Away from Losing</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($players as $key => $player): ?>
        <tr class="player-row<?php echo ($key + 1); ?>">
          <td><?php echo $player['name']; ?></td>
          <td><?php echo $player['average']; ?></td>
          <td><?php echo $player['three_darts']; ?></td>
          <td><?php echo $player['one_darts']; ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
