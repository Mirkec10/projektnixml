<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>World Darts Championship</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header class="d-flex justify-content-between align-items-center">
        <img src="images/logo.png" alt="Logo">
        <nav>
            <a href="index.php">Home</a>
            <a href="averages.php">Player Averages</a>
            <a href="champions.php">Champions</a>
        </nav>
    </header>
    
    <div class="container">
        <h2>Upcoming Events</h2>
        <div class="table-responsive">
            <table class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>Location</th>
                        <th>Year</th>
                        <th>Arena</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $events = json_decode(file_get_contents('events.json'), true);
                    foreach ($events as $event) {
                        echo "<tr>
                                <td>{$event['location']}</td>
                                <td>{$event['year']}</td>
                                <td>{$event['arena']}</td>
                                <td>{$event['date']}</td>
                              </tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
        
        <h2>Latest News</h2>
        <div class="responsive-columns">
            <div class="column">
                <img src="images/littler.jpg" alt="News 1">
                <h3>Shining Star</h3>
                <p>Luke Littler, a young talent in the world of darts, has already caught the attention of many with his impressive performances. At just 17 years old, he has shown remarkable maturity and skill, allowing him to compete against more experienced players. Expectations for 2024 are high, with many experts believing Luke will continue to rise in the world rankings.</p>
            </div>
            <div class="column">
                <img src="images/arena.png" alt="News 2">
                <h3>Tickets</h3>
                <p>Don't miss out on the event of the year! Tickets are selling like hotcakes for the most anticipated gathering in town. Whether it's an electrifying concert, a thrilling sports match, or a captivating theatrical performance, we've got the ticket that will make your day unforgettable.</p>
            </div>
            <div class="column">
                <img src="images/enter.jpg" alt="News 3">
                <h3>Atmosphere</h3>
                <p>Feel the thrill in the air as you become part of something extraordinary. With every beat of the music and every cheer from the crowd, you'll be swept away on a journey of pure exhilaration. Don't just attend an event; be part of an unforgettable experience that will leave you breathless and wanting more.</p>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
